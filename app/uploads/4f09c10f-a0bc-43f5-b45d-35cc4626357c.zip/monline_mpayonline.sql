-- phpMyAdmin SQL Dump
-- version 3.4.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 08, 2012 at 11:09 PM
-- Server version: 5.1.56
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `monline_mpayonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `p_onlinetrans`
--

CREATE TABLE IF NOT EXISTS `p_onlinetrans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_persian_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `au` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `amount` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `date` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `p_onlinetrans`
--

INSERT INTO `p_onlinetrans` (`id`, `name`, `email`, `desc`, `au`, `amount`, `date`, `status`) VALUES
(1, 'مهرداد جتنت دوست', 'mehrdad.jannatdoust@gmail.com', 'پرداخت بدهی', '-2', '25000', 1317206790, 0),
(2, 'مهرداد', '', '', '-1', '0', 1317219061, 0),
(3, 'مهرداد جنت دوست', 'mehrdad.jannatdoust@gmail.com', 'تست پرداخت', '4e833048-236c-43c7-86b6-05b06a9c8b43', '1000', 1317219081, 1),
(4, 'پیام خانی نژاد', 'progvig@yahoo.com', 'بابت دومین', '4e8d540c-7b2c-4527-a9ee-64366a9c8b43', '12000', 1317883563, 1),
(5, 'مهرداد جنت دوست', 'mehrdad.jannatdoust@gmail.com', 'بابت تست پرداخت', '4e8d7d39-1008-40b4-8ec5-34746a9c8b43', '1000', 1317894103, 1),
(6, 'امید ظریفی', 'zarifi.omid@gmail.com', 'تست', '4e92cc0c-bde4-42fc-86d5-14406a9c8b43', '1000', 1318241945, 1),
(7, 'سعید کامکار', 'skamkar2010@gmail.com', 'بابت بدهی', '4e9c3af2-fd54-4cce-b7b3-4fb36a9c8b43', '30000', 1318860127, 0),
(8, '', '', '', '-1', '0', 1320594121, 0);

-- --------------------------------------------------------

--
-- Table structure for table `p_settings`
--

CREATE TABLE IF NOT EXISTS `p_settings` (
  `id` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `address` text COLLATE utf8_persian_ci NOT NULL,
  `phonenum` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `desc` text COLLATE utf8_persian_ci NOT NULL,
  `mail_address` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `mail_title` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `send_email` tinyint(1) NOT NULL,
  `website` varchar(60) COLLATE utf8_persian_ci NOT NULL,
  `pin` varchar(36) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `p_settings`
--

INSERT INTO `p_settings` (`id`, `name`, `address`, `phonenum`, `desc`, `mail_address`, `mail_title`, `send_email`, `website`, `pin`) VALUES
(1, 'بـخش پـرداخت آنــلاین گـروه انـفورماتیـک ایـران تـیم', 'خدمات هاستینگ ، دامنه ، طراحی سایت و برنامه نویسی', '', 'خدمات هاستینگ ، دامنه ، طراحی سایت و برنامه نویسی', 'support@iranteam.ir', 'سامانه پرداخت آنلاین ایران تیم', 1, 'http://mpay.iranteam.ir', '4e83289b-7e3c-4153-881c-4cf5ae8e8897');

-- --------------------------------------------------------

--
-- Table structure for table `p_users`
--

CREATE TABLE IF NOT EXISTS `p_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(35) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `p_users`
--

INSERT INTO `p_users` (`id`, `email`, `password`, `name`, `role`) VALUES
(1, 'support@iranteam.ir', '6aa30d0c9de51db9ea20ac0b36b2941153b4cc21', 'مدير سايت', 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
